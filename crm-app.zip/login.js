// Handle normal login
document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // Yaha firebase se connect karenge baad me
  console.log('Email Login Attempt:', email, password);

  // Dummy redirect
  window.location.href = 'dashboard.html';
});

// Handle Google Login
document.getElementById('googleLogin').addEventListener('click', function() {
  // Baad me firebase Google Sign-In yaha connect karenge
  console.log('Google Login Clicked');
  window.location.href = 'dashboard.html';
});

// Handle Mobile Login
document.getElementById('mobileLogin').addEventListener('click', function() {
  // Baad me firebase Phone Auth connect karenge
  console.log('Mobile Login Clicked');
  window.location.href = 'dashboard.html';
}); 