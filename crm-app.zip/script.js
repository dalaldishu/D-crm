let customers = [];
let editIndex = -1;

document.getElementById("customerForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();

  if (name && email && phone) {
    const newCustomer = { name, email, phone };

    if (editIndex === -1) {
      // New customer add
      customers.push(newCustomer);
    } else {
      // Existing customer update
      customers[editIndex] = newCustomer;
      editIndex = -1;
      document.getElementById("submitBtn").textContent = "Add Customer";
    }

    displayCustomers();
    document.getElementById("customerForm").reset();
  }
});

function loadCustomers() {
  displayCustomers();
}

function deleteCustomer(index) {
  customers.splice(index, 1);
  displayCustomers();
}

function editCustomer(index) {
  const customer = customers[index];
  document.getElementById("name").value = customer.name;
  document.getElementById("email").value = customer.email;
  document.getElementById("phone").value = customer.phone;
  editIndex = index;
  document.getElementById("submitBtn").textContent = "Update Customer";
}

function displayCustomers() {
  const customerList = document.getElementById("customerList");
  customerList.innerHTML = "";

  customers.forEach((customer, index) => {
    const div = document.createElement("div");
    div.innerHTML = `
      <strong>${customer.name}</strong> - ${customer.email} - ${customer.phone}
      <button onclick="editCustomer(${index})" style="margin-left:10px;">Edit</button>
      <button onclick="deleteCustomer(${index})" style="margin-left:5px;">Delete</button>
    `;
    customerList.appendChild(div);
  });

  document.getElementById("customerCount").textContent = customers.length;
} 